package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HotelLoginPageFactory 
{
	WebDriver driver;
	
	//Step1: Identify HTML Elements
	@FindBy(name="userName")
	WebElement pfname;
	
	@FindBy(how=How.NAME, using="userPwd")
	WebElement ppwd;
	
	@FindBy(className="btn")
	WebElement plogin;
	
	//Initiating Elements
	public HotelLoginPageFactory(WebDriver driver)
	{	
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}

	
	//setters
	public void setPfname(String suname) {
		pfname.sendKeys(suname);
	}

	public void setPpwd(String spwd) {
		ppwd.sendKeys(spwd);
	}

	public void setPlogin() {
		plogin.click();
	}
	
	public WebElement getPpwd() {
		return ppwd;
	}

	public WebDriver getDriver() {
		return driver;
	}


	public WebElement getPfname() {
		return pfname;
	}


	public WebElement getPlogin() {
		return plogin;
	}

	

}
