package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HotelBookingPageFactory
{
WebDriver driver;
	
	//Step1: Identify HTML Elements
	@FindBy(name="txtFN")
	WebElement fname;
	
	@FindBy(name="txtLN")
	WebElement lname;
	
	@FindBy(name="Email")
	WebElement email;
	
	@FindBy(name="Phone")
	WebElement ph;
	
	@FindBy(name="persons")
	WebElement people;
	
	@FindBy(linkText="Click Here!")
	WebElement link;
	
	@FindBy(name="a")
	WebElement gender;
	

	@FindBy(name="city")
	WebElement city;
	
	@FindBy(name="state")
	WebElement state;
	
	@FindBy(id="txtCardholderName")
	WebElement cardname;
	
	@FindBy(id="txtDebit")
	WebElement debit;
	
	@FindBy(id="txtCvv")
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	WebElement month;
	
	@FindBy(id="txtYear")
	WebElement year;
	
	@FindBy(id="btnPayment")
	WebElement button;

	
	public HotelBookingPageFactory(WebDriver driver)
	{	
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}


	public WebElement getFname() {
		return fname;
	}


	public WebElement getLname() {
		return lname;
	}


	public WebElement getEmail() {
		return email;
	}


	public WebElement getPh() {
		return ph;
	}


	public WebElement getCity() {
		return city;
	}


	public WebElement getState() {
		return state;
	}


	public WebElement getCardname() {
		return cardname;
	}


	public WebElement getDebit() {
		return debit;
	}


	public WebElement getCvv() {
		return cvv;
	}


	public WebElement getMonth() {
		return month;
	}


	public WebElement getYear() {
		return year;
	}


	public WebElement getButton() {
		return button;
	}

	
	public WebElement getPeople() {
		return people;
	}


	public void setPeople(String arg1) {
		people.sendKeys(arg1);
	}

	
	//setters
	public void setFname(String firstname) {
		fname.sendKeys(firstname);
	}


	public void setLname(String lastname) {
		lname.sendKeys(lastname);
	}


	public void setEmail(String em) {
		email.sendKeys(em);
	}


	public void setPh(String name) {
		ph.sendKeys(name);
	}


	public void setCity(String name) {
		city.sendKeys(name);
	}


	public void setState(String name) {
		state.sendKeys(name);
	}


	public void setCardname(String name) {
		cardname.sendKeys(name);
	}


	public void setDebit(String name) {
		debit.sendKeys(name);
	}


	public void setCvv(String name) {
		cvv.sendKeys(name);
	}


	public void setMonth(String name) {
		month.sendKeys(name);
	}


	public void setYear(String name) {
		year.sendKeys(name);
	}


	public void setButton() {
		button.click();
	}


	public WebElement getLink() {
		return link;
	}


	public void setLink() {
		link.click();
	}


	public WebElement getGender() {
		return gender;
	}


	public void setGender(String gen) {
	//
	}
	
}
