package Hotel;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import PageBean.HotelBookingPageFactory;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelStepDefn {
	
	private WebDriver driver;
	private HotelBookingPageFactory objhbpf; 

	@Given("^User is on booking page$")
	public void user_is_on_booking_page() throws Throwable {
		driver = new FirefoxDriver();
		   //driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		   Thread.sleep(2000);
		   objhbpf = new HotelBookingPageFactory(driver);
		   driver.get("file:///D:/MATERIALS/hotelBooking/hotelbooking.html");
		   
	}

	@Then("^check the heading of page$")
	public void check_the_heading_of_page() throws Throwable {
		 String title = driver.getTitle();
		    if(title.equals("Hotel Booking")) {
		    	System.out.println("Title Correct");
		    }else {
		    	System.out.println("Title Wrong!");
		    }
		   
	}

	@When("^User does not enter firstname , lastname$")
	public void user_does_not_enter_firstname_lastname() throws Throwable {
		objhbpf.setFname("");
		   objhbpf.setLname("");
		   Thread.sleep(1000);
		   objhbpf.setButton();
	}

	@Then("^prompt user to fill in details$")
	public void prompt_user_to_fill_in_details() throws Throwable {
		driver.switchTo().alert();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    Thread.sleep(1000);
	    driver.close();
	}

	@When("^User does not enter email in correct format$")
	public void user_does_not_enter_email_in_correct_format() throws Throwable {
		objhbpf.setFname("Priya");
	    Thread.sleep(1000);
	    objhbpf.setLname("Khosla");
		objhbpf.setEmail("");
	    Thread.sleep(1000);
	    objhbpf.setButton();
	}

	@Then("^prompt user to write input correctly$")
	public void prompt_user_to_write_input_correctly() throws Throwable {
		driver.switchTo().alert();
		   Thread.sleep(1000);
		   driver.switchTo().alert().accept();
		   Thread.sleep(2000);
		  Thread.sleep(1000);
		  driver.close();
	}

	@When("^User does not enter mobile number$")
	public void user_does_not_enter_mobile_number() throws Throwable {
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
		objhbpf.setPh("");
	    Thread.sleep(1000);
	    objhbpf.setButton();
	}

	@Then("^prompt user to enter mobile number$")
	public void prompt_user_to_enter_mobile_number() throws Throwable {
	    driver.switchTo().alert();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
	}
	
	@When("^User enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
	    
	    List<String> objList=arg1.asList(String.class);
	    
	    for(int i=0;i<objList.size();i++)
	    {
	    	objhbpf.getPh().clear();
	    	objhbpf.setPh(objList.get(i));
	    	Thread.sleep(1000);
	    	objhbpf.setButton();
	    	
	    	if(Pattern.matches("^[7-9]{1}[0-9]{9}$" ,objList.get(i)))
	    	{
	    		System.out.println("*****Matched******"+objList.get(i));
	    		
	    	}
	    	else
	    	{
	    		String alertMessage=driver.switchTo().alert().getText();
	    		Thread.sleep(1000);
	    		driver.switchTo().alert().accept();
	    		System.out.println("*****"+alertMessage);
	    		System.out.println("*****Not Matched*****"+objList.get(i));
	    	}
	    	
	    }
	  	objhbpf.setButton();

	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		  driver.switchTo().alert();
		    Thread.sleep(1000);
		    driver.switchTo().alert().accept();
		    Thread.sleep(1000);
		    driver.close();
	  
	}




	@When("^User does not select city$")
	public void user_does_not_select_city() throws Throwable {
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
	    objhbpf.setPh("8879542350");
	    
		objhbpf.setCity("Select City");
		objhbpf.setButton();
		
	}

	@Then("^prompt user to select city$")
	public void prompt_user_to_select_city() throws Throwable {
		
		driver.switchTo().alert();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
		 
	}

	@When("^User does not select state$")
	public void user_does_not_select_state() throws Throwable {
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
	    objhbpf.setPh("8879542350");
	    objhbpf.setCity("Pune");
	    objhbpf.setState("Select State");
		objhbpf.setButton();
	}

	@Then("^prompt user to select state$")
	public void prompt_user_to_select_state() throws Throwable {
		driver.switchTo().alert();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		Thread.sleep(1000);
		driver.close();
	}
	
	
	@When("^user enters (\\d+)$")
	public void user_enters(String arg1) throws Throwable {
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
	    objhbpf.setPh("8879542350");
	    objhbpf.setCity("Pune");
	    objhbpf.setState("Maharashtra");
	    objhbpf.setPeople(arg1);
	    Thread.sleep(1000);
	
	    
	}

	@Then("^for (\\d+) allocate (\\d+)$")
	public void for_allocate(int arg1, int arg2) throws Throwable {
		System.out.println("*****Rooms: "+arg2);
		if(arg1<=3)
			assertEquals(1,arg2);
		else if(arg1<=6)
			assertEquals(2,arg2);
		else if(arg1<=9)
			assertEquals(3,arg2);
		
		
	}



	@When("^User does not enter card holder name$")
	public void user_does_not_enter_card_holder_name() throws Throwable {
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
	    objhbpf.setPh("8879542350");
	    objhbpf.setCity("Pune");
	    objhbpf.setState("Maharashtra");
	    objhbpf.setPeople("4");
		objhbpf.setCardname("");
	   objhbpf.setButton();
	   
	}

	@Then("^prompt user to fill in card holder name$")
	public void prompt_user_to_fill_in_card_holder_name() throws Throwable {
		driver.switchTo().alert();
		   Thread.sleep(1000);
		   driver.switchTo().alert().accept();
		  // objhbpf.setCardname("Priya");
		   Thread.sleep(1000);
		   driver.close();
	}

	@When("^User does not enter debit card number$")
	public void user_does_not_enter_debit_card_number() throws Throwable {
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
	    objhbpf.setPh("8879542350");
	    objhbpf.setCity("Pune");
	    objhbpf.setState("Maharashtra");
	    objhbpf.setPeople("4");
	    objhbpf.setCardname("Priya");
		objhbpf.setDebit("");
	    objhbpf.setButton();
	}

	@Then("^prompt user to enter debit card number$")
	public void prompt_user_to_enter_debit_card_number() throws Throwable {
	    driver.switchTo().alert();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	   // objhbpf.setDebit("789456123");
	  //  Thread.sleep(1000);
	   driver.close();
	}

	@When("^User does not enter card expiration month$")
	public void user_does_not_enter_card_expiration_month() throws Throwable {
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
	    objhbpf.setPh("8879542350");
	    objhbpf.setCity("Pune");
	    objhbpf.setState("Maharashtra");
	    objhbpf.setPeople("4");
	    objhbpf.setCardname("Priya");
	    objhbpf.setDebit("789456123");
	    objhbpf.setCvv("555");
		objhbpf.setMonth("");
	    objhbpf.setButton();
	}

	@Then("^prompt user to enter card expiration month$")
	public void prompt_user_to_enter_card_expiration_month() throws Throwable {
	    driver.switchTo().alert();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	   // objhbpf.setMonth("05");
	   // Thread.sleep(1000);
	   driver.close();
	}

	@When("^User does not enter card expiration year$")
	public void user_does_not_enter_card_expiration_year() throws Throwable {
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
	    objhbpf.setPh("8879542350");
	    objhbpf.setCity("Pune");
	    objhbpf.setState("Maharashtra");
	    objhbpf.setPeople("4");
	    objhbpf.setCardname("Priya");
	    objhbpf.setDebit("789456123");
	    objhbpf.setCvv("555");
	    objhbpf.setMonth("05");
		objhbpf.setYear("");
	    objhbpf.setButton();
	}

	@Then("^prompt user to enter card expiration year$")
	public void prompt_user_to_enter_card_expiration_year() throws Throwable {
		driver.switchTo().alert();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	   // objhbpf.setYear("2018");
	   // Thread.sleep(1000);
	    driver.close();
	}

	@When("^User clicks on confirm booking button$")
	public void user_clicks_on_confirm_booking_button() throws Throwable {
		objhbpf.setFname("Priya");
	    objhbpf.setLname("Khosla");
	    objhbpf.setEmail("p731996@gmail.com");
	    objhbpf.setPh("8879542350");
	    objhbpf.setCity("Pune");
	    objhbpf.setState("Maharashtra");
	    objhbpf.setPeople("4");
	    objhbpf.setCardname("Priya");
	    objhbpf.setDebit("789456123");
	    objhbpf.setCvv("555");
	    objhbpf.setMonth("05");
	    objhbpf.setYear("2018");
		//objhbpf.setButton();
		objhbpf.setLink();
		
	    
	}

	@Then("^navigate to booking successful$")
	public void navigate_to_booking_successful() throws Throwable {
	    driver.navigate().to("file:///D:/MATERIALS/hotelBooking/success.html");
	    Thread.sleep(3000);
	    driver.close();
	}
}
