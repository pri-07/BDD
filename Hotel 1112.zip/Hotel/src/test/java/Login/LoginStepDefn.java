package Login;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageBean.HotelLoginPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefn {
	
	
	private WebDriver driver;
	private HotelLoginPageFactory objhlpf;
	
	@Given("^User is on login page$")
	public void user_is_on_login_page() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhlpf=new HotelLoginPageFactory(driver);
		
		driver.get("file:///D:/MATERIALS/hotelBooking/login.html");
	}

	
	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		// throw new PendingException();
		String strheading=driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/h1")).getText();
		if(strheading.equals("Hotel Booking Application"))
		{
			System.out.println("heading matched");
		}
		else
		{
			System.out.println("heading not matched");
		}
	}


	@When("^user enters valid username,valid password$")
	public void user_enters_valid_username_valid_password() throws InterruptedException {
	   objhlpf.setPfname("capgemini");
	   objhlpf.setPpwd("capg1234");
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   objhlpf.setPlogin();
	   driver.close();
	}

	@Then("^navigate to hotelBooking$")
	public void navigate_to_hotelBooking() throws InterruptedException {
	    driver.navigate().to("file:///D:/MATERIALS/hotelBooking/hotelbooking.html");
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    driver.close();
	}

	@When("^user does not enter either username or password$")
	public void user_does_not_enter_either_username_or_password() throws InterruptedException {
	   objhlpf.setPfname("");
	   Thread.sleep(1000);
	  // objhlpf.setPpwd("capg1234");
	}

	@When("^clicks the login Button$")
	public void clicks_the_login_Button() throws InterruptedException {
		objhlpf.setPlogin();
		Thread.sleep(1000);
	   
	}

	//@Then("^[a=z]$")
	@Then("^display appropriate message$")
	public void display_appropriate_message() throws InterruptedException {
		String strheading=driver.findElement(By.xpath("/html/body/div/div[1]/form/table/tbody/tr[2]/td[3]/div")).getText();
		assertEquals(strheading,"* Please enter userName.");
		//driver.close();
	    
	}

	@When("^user enters incorrect username or password$")
	public void user_enters_incorrect_username_or_password() throws InterruptedException {
		objhlpf.setPfname("cg");
		objhlpf.setPpwd("capg1234");
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 objhlpf.setPlogin();
	   
	}

	@Then("^display login failed message$")
	public void display_login_failed_message() throws InterruptedException {
		
		String alertMessage=driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("****"+alertMessage);
	   driver.close();
	}



}
