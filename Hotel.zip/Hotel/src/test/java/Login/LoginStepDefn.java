package Login;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefn {
	
	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		// throw new PendingException();
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters valid username,valid password$")
	public void user_enters_valid_username_valid_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^navigate to hotelBooking$")
	public void navigate_to_hotelBooking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user does not enter either username or password$")
	public void user_does_not_enter_either_username_or_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicks the login Button$")
	public void clicks_the_login_Button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display appropriate message$")
	public void display_appropriate_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters incorrect username or password$")
	public void user_enters_incorrect_username_or_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display login failed message$")
	public void display_login_failed_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}



}
