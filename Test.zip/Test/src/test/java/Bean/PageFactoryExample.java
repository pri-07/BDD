package Bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageFactoryExample {
	
	WebDriver driver;
	
	@FindBy(id="txtUserName")
	WebElement username;
	
	@FindBy(xpath="//*[@id='txtPassword']")
	WebElement password;
	
	@FindBy(id="txtConfPassword")
	WebElement confirmpassword;
	
	@FindBy(id="txtFirstName")
	WebElement fname;
	
	@FindBy(id="txtLastName")
	WebElement lname;
	
	@FindBy(name="gender")
	WebElement gender;
	
	@FindBy(id="DOB")
	WebElement date;
	
	@FindBy(id="txtEmail")
	WebElement email;
	
	@FindBy(name="Address")
	WebElement address;
	
	@FindBy(name="City")
	WebElement city;
	
	@FindBy(id="txtPhone")
	WebElement phone;
	
	@FindBy(name="chkHobbies")
	WebElement hobbies;
	
	@FindBy(name="submit")
	WebElement submit;
	
	@FindBy(name="reset")
	WebElement reset;

	public WebElement getUsername() {
		return username;
	}

	public WebElement getPassword() {
		return password;
	}

	public WebElement getConfirmpassword() {
		return confirmpassword;
	}

	public WebElement getFname() {
		return fname;
	}

	public WebElement getLname() {
		return lname;
	}

	public WebElement getGender() {
		return gender;
	}

	public WebElement getDate() {
		return date;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getAddress() {
		return address;
	}

	public WebElement getCity() {
		return city;
	}

	public WebElement getPhone() {
		return phone;
	}

	public WebElement getHobbies() {
		return hobbies;
	}

	public WebElement getSubmit() {
		return submit;
	}

	public WebElement getReset() {
		return reset;
	}

	//Setters
	public void setUsername(String name) {
		username.sendKeys(name);
	}

	public void setPassword(String pass) {
		password.sendKeys(pass);
	}

	public void setConfirmpassword(String confirm) {
		confirmpassword.sendKeys(confirm);
	}

	public void setFname(String first) {
		fname.sendKeys(first);
	}

	public void setLname(String last) {
		lname.sendKeys(last);
	}

	public void setGender(String gen) {
		if(gen.equals("Male"))
		{
			driver.findElement(By.xpath("//*[@id='rbMale']")).click();
		}
		else if(gen.equals("Female"))
		{
			driver.findElement(By.xpath("//*[@id='rbFemale']")).click();
		}
		else
			System.out.println("No option selected");
	}

	public void setDate(String dob) {
		date.sendKeys(dob);
	}

	public void setEmail(String mail) {
		email.sendKeys(mail);
	}

	public void setAddress(String add) {
		address.sendKeys(add);
	}

	public void setCity(String pfcity) {
		if(pfcity.equals("Mumbai"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[10]/td[2]/select/option[1]")).click();
		}
		else if(pfcity.equals("Pune"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[10]/td[2]/select/option[2]")).click();
		}
		else if(pfcity.equals("Bangalore"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[10]/td[2]/select/option[3]")).click();
		}
		else if(pfcity.equals("Chennai"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[10]/td[2]/select/option[4]")).click();
		}
		else
			System.out.println("No option selected");
	}

	public void setPhone(String pfphone) {
		phone.sendKeys(pfphone);
	}

	public void setHobbies(String pfhobbies) {
		if(pfhobbies.equals("Music"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input[1]")).click();
		}
		else if(pfhobbies.equals("Movies"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input[2]")).click();
		}
		else if(pfhobbies.equals("Reading"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input[3]")).click();
		}
	}
		

	public void setSubmit() {
		submit.click();
	}

	public void setReset() {
		reset.click();
	}

	public PageFactoryExample(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
}
