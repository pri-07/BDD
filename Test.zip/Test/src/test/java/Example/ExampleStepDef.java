package Example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import Bean.PageFactoryExample;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExampleStepDef {
	private WebDriver driver;
	private PageFactoryExample pfexample;
	
	@Given("^User is on main page$")
	public void user_is_on_main_page() throws Throwable {
		driver = new FirefoxDriver();
		   pfexample=new PageFactoryExample(driver);
		   driver.get("file:///D:/MATERIALS/BddDemo2/Lesson%205-HTML%20Pages/WorkingWithForms.html");
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
		 String title = driver.getTitle();
		    if(title.equals("Email Registration Forms")) {
		    	System.out.println("Title Correct");
		    }else {
		    	System.out.println("Title Wrong!");
		    }
		    
	
	}

	@When("^User enters different values for password and confirm password$")
	public void user_enters_different_values_for_password_and_confirm_password() throws Throwable {
		pfexample.setUsername("Priyanka");
		pfexample.setPassword("lmnop");
		Thread.sleep(1000);
		pfexample.setConfirmpassword("elemenop");
		Thread.sleep(1000);
		pfexample.setSubmit();
	   
	}

	@Then("^prompt user to enter same values for passwords$")
	public void prompt_user_to_enter_same_values_for_passwords() throws Throwable {
		driver.switchTo().alert();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	
	}

	@When("^User enters details in all specified fields$")
	public void user_enters_details_in_all_specified_fields() throws Throwable {
		
		pfexample.setUsername("Priyanka");
		pfexample.setPassword("lmnop");
		Thread.sleep(1000);
		pfexample.setConfirmpassword("lmnop");
		Thread.sleep(1000);
		pfexample.setFname("Priya");
		Thread.sleep(1000);
		pfexample.setLname("Khosla");
		Thread.sleep(1000);
		pfexample.setGender("Female");
		Thread.sleep(1000);
		pfexample.setDate("15/11/2016");
		Thread.sleep(1000);
		pfexample.setEmail("priya.khosla@capg.com");
		Thread.sleep(1000);
		pfexample.setAddress("Apne ghar");
		Thread.sleep(1000);
		pfexample.setCity("Mumbai");
		Thread.sleep(1000);
		pfexample.setCity("Pune");
		Thread.sleep(1000);
		pfexample.setCity("Bangalore");
		Thread.sleep(1000);
		pfexample.setPhone("9898989898");
		Thread.sleep(1000);	
		pfexample.setHobbies("Music");
		Thread.sleep(1000);
		pfexample.setHobbies("Movies");
		Thread.sleep(1000);
	
	}

	@When("^User clicks on submit button$")
	public void user_clicks_on_submit_button() throws Throwable {
		pfexample.setSubmit();
	//	Thread.sleep(1000);
	    
	}

	@Then("^submit details entered by user$")
	public void submit_details_entered_by_user() throws Throwable {
	    driver.navigate().to("file:///D:/MATERIALS/BddDemo2/Lesson%205-HTML%20Pages/hello.html");
	}
	
	

}
