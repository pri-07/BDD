package Example;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class bddexample {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
   // baseUrl = "file:///D:/MATERIALS/BddDemo2/Lesson%205-HTML%20Pages/WorkingWithForms.html";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testBddexample() throws Exception {
    driver.get("file:///D:/MATERIALS/BddDemo2/Lesson%205-HTML%20Pages/WorkingWithForms.html");
    driver.findElement(By.id("txtUserName")).clear();
    driver.findElement(By.id("txtUserName")).sendKeys("prkhosla");
    driver.findElement(By.id("txtPassword")).clear();
    driver.findElement(By.id("txtPassword")).sendKeys("12345");
//    driver.findElement(By.id("txtConfPassword")).clear();
//    driver.findElement(By.id("txtConfPassword")).sendKeys("123456");
//    try {
//      assertEquals("Passwords donot match!", closeAlertAndGetItsText());
//    } catch (Error e) {
//      verificationErrors.append(e.toString());
//    }
    driver.findElement(By.id("txtConfPassword")).clear();
    driver.findElement(By.id("txtConfPassword")).sendKeys("12345");
    driver.findElement(By.id("txtFirstName")).clear();
    driver.findElement(By.id("txtFirstName")).sendKeys("Priya");
    driver.findElement(By.id("txtLastName")).clear();
    driver.findElement(By.id("txtLastName")).sendKeys("Khosla");
    driver.findElement(By.id("rbFemale")).click();
    driver.findElement(By.id("DOB")).clear();
    driver.findElement(By.id("DOB")).sendKeys("7/3/1996");
    driver.findElement(By.id("txtEmail")).clear();
    driver.findElement(By.id("txtEmail")).sendKeys("p731996@gmail.com");
    driver.findElement(By.id("txtAddress")).clear();
    driver.findElement(By.id("txtAddress")).sendKeys("Mumbai");
    // ERROR: Caught exception [ERROR: Unsupported command [addSelection | name=City | label=Mumbai]]
    driver.findElement(By.id("txtPhone")).clear();
    driver.findElement(By.id("txtPhone")).sendKeys("9999999999");
    // ERROR: Caught exception [Error: Dom locators are not implemented yet!]
    // ERROR: Caught exception [Error: Dom locators are not implemented yet!]
    driver.findElement(By.name("submit")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
